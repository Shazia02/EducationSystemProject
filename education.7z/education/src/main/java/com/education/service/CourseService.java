package com.education.service;

public interface CourseService {
	
	//List<Course> getAllCourse();

}
