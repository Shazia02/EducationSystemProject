package com.student.exception;

public class StudentNotfoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2983027943211021616L;

	public StudentNotfoundException(){
		
	}
}
