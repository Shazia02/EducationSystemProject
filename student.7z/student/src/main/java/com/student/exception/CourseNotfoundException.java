package com.student.exception;

public class CourseNotfoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4326447529008821506L;

	public CourseNotfoundException() {
		
	}
	
}
